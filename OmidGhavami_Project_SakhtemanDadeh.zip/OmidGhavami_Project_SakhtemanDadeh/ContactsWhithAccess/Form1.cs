﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContactsWhithAccess
{
    public partial class Form1 : Form
    {
        private int EditID = 0;
        private static string Connection = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + @"\ContactsDB.accdb";
        public Form1()
        {
            InitializeComponent();
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            lblValidate.Visible = (txtName.Text.Trim() == "");
        }

        private void txtTell_TextChanged(object sender, EventArgs e)
        {
            lblValidate1.Visible = (txtTell.Text.Trim() == "");
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            lblValidate2.Visible = (txtEmail.Text.Trim() == "");
        }
        void ResetText()
        {
            txtEmail.Text = "";
            txtName.Text = "";
            txtTell.Text = "";
            txtSearch.Text = "";
            EditID = 0;
            button1.Text = "ثبت";
        }
        void BindGrid()
        {
            OleDbConnection con = new OleDbConnection(Connection);
            OleDbDataAdapter da=new OleDbDataAdapter("Select * From Contacts",con);
            DataSet ds=new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!lblValidate.Visible && !lblValidate1.Visible && !lblValidate2.Visible)
            {
                if(EditID==0)
                {
                    OleDbConnection con = new OleDbConnection(Connection);
                    OleDbCommand com = new OleDbCommand("Insert Into Contacts (FullName,Tell,Email) Values (@FullName,@Tell,@Email)", con);
                    com.Parameters.AddWithValue("@FullName", txtName.Text);
                    com.Parameters.AddWithValue("@Tell",txtTell.Text);
                    com.Parameters.AddWithValue("@Email",txtEmail.Text);
                    con.Open();
                    com.ExecuteNonQuery();
                    con.Close();
                   
                }
                else
                {
                    OleDbConnection con = new OleDbConnection(Connection);
                    OleDbCommand com = new OleDbCommand("Update Contacts Set FullName=@FullName,Tell=@Tell,Email=@Email Where ID="+EditID, con);
                    com.Parameters.AddWithValue("@FullName", txtName.Text);
                    com.Parameters.AddWithValue("@Tell", txtTell.Text);
                    com.Parameters.AddWithValue("@Email", txtEmail.Text);
                    con.Open();
                    com.ExecuteNonQuery();
                    con.Close();  
                }
                ResetText();
                BindGrid();
            }
            else
            {
                MessageBox.Show("لطفا مقادیر را کامل وارد کنید");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if(txtSearch.Text.Trim()!="")
            {
                OleDbConnection con = new OleDbConnection(Connection);
                OleDbDataAdapter da = new OleDbDataAdapter("Select * From Contacts Where FullName Like'%"+txtSearch.Text+"%'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
            }
            else
            {
                BindGrid();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(dataGridView1.CurrentRow!=null)
            {
                txtName.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                txtTell.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                txtEmail.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                EditID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                button1.Text = "ویرایش";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ResetText();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                if(MessageBox.Show("آیا از حذف مطمئن هستید ؟","هشدار",MessageBoxButtons.YesNo)==DialogResult.Yes)
                {
                    int ID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                    OleDbConnection con = new OleDbConnection(Connection);
                    OleDbCommand com = new OleDbCommand("Delete From Contacts Where ID=" + ID, con);
                    con.Open();
                    com.ExecuteNonQuery();
                    con.Close(); 
                    BindGrid();
                }
            }
        }
    }
}
